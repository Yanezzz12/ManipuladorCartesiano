# AX-12A-ESP8266

Arduino library to control Dynamixel AX-12A <br>
https://github.com/jumejume1/AX-12A-servo-library

![Maker Tutor](https://4.bp.blogspot.com/-86dE-3eEZts/W8l87mROgdI/AAAAAAABL2s/x-neoYUOEI4116yHHbAozHmYShUEWV0lwCLcBGAs/s640/Screen%2BShot%2B2561-10-19%2Bat%2B13.40.48.png)

[![Maker Tutor](https://img.youtube.com/vi/aYE_O_ZF2ac/0.jpg)](https://www.youtube.com/watch?v=aYE_O_ZF2ac)
